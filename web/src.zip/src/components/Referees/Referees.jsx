//  TODO: Implement
function Referees() {
  return 'REFEREES_PAGE';
}

export default Referees;
