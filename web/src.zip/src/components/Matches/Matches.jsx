// TODO: Implement
function Matches() {
  return 'MATCHES_PAGE';
}

export default Matches;
